#!/usr/bin/perl
#
############################
# LDAP Integration Tests
#   by wenye@eucalyptus.com
############################

use strict;

open(STDERR, ">&STDOUT");

#### Constants
my $TIMEOUT = 60;
my $EUCALYPTUS = (defined($ARGV[0]) ? $ARGV[0] : '/');
my $ARCH = (defined($ARGV[1]) ? $ARGV[1] : '64');
my @EUCAVARS = ("S3_URL", "AWS_SNS_URL", "EC2_URL", "EUARE_URL", "EC2_PRIVATE_KEY", "EC2_CERT", "EC2_JVM_ARGS", "EUCALYPTUS_CERT", "EC2_ACCESS_KEY", "EC2_SECRET_KEY", "AWS_CREDENTIAL_FILE", "EC2_USER_ID");
my $LDAPROOT = "./ldaproot";
my $SLAPD = "bin/slapd." . $ARCH ;
my $SLAPDCONF = "etc/openldap/slapd.conf";
my $SLAPDDATA = "etc/openldap/eucalyptus";
my $INITLDIF = "./init.ldif";
my $TESTLIC = "./test.lic";
my $DEFAULTLIC = "./default.lic";
my $LICPROPERTY = "authentication.ldap_integration_configuration";
my $MAXSYNCTIME = 1800;

#### Subroutines
# Fail
sub fail {
  my($message) = @_;
  print("[TEST_REPORT] FAILED - $message\n");
  #exit(1);
}

sub pass {
  my($message) = @_;
  print("[TEST_REPORT] PASSED - $message\n");
  return 0;
}

# Print test name
sub test_name {
  my($name) = @_;
  print("\n\n[TEST_CASE]: >>>>> $name <<<<<\n");
}
# Run a system command and get output in a list
sub sys {

  my($cmd) = @_;
  print("Timeout=$TIMEOUT Command:$cmd\n");
  my @output;
  	# Return and print failure 
  	$SIG{ALRM} = sub { die "alarm\n"; };
	eval {
    alarm($TIMEOUT);
	@output = `$cmd`;
	alarm(0);
	
	};
	if ($@) {
		die unless $@ eq "alarm\n"; # propagate unexpected errors
		# timed out
		fail("Timeout occured after $TIMEOUT seconds\n"); 
		return @output;
	}
	else {		# didn't
		print "OUTPUT:\n" . "@output\n";
		return @output;
    
	}
	
}

# Get credentials
sub get_cred {
  my($account, $user) = @_;
  my $cred_dir = "eucarc-$account-$user";
  mkdir($cred_dir);
  my $cmd = $EUCALYPTUS . "/usr/sbin/euca_conf --get-credentials $cred_dir/euca.zip --cred-account $account --cred-user $user";
  sys($cmd);
  my $pwd = $ENV{"PWD"};
  chdir($cred_dir);
  system("unzip -o euca.zip");
  chdir($pwd);
  if (!-e "$cred_dir/eucarc") {
    fail("download credentials for $user in $account failed");
  }
  return "$cred_dir/eucarc";
}

# Use credentials
# emulate the bash "source" to populate local ENV with eucarc
sub use_cred {
  my($cred_path) = @_;
  my @envs = `bash -c ". $cred_path; set"`;
  my %envmap = {};
  for my $line (@envs) {
    chomp($line);
    my @components = split(/=/, $line, 2);
    $envmap{$components[0]} = $components[1];
  }
  for my $var (@EUCAVARS) {
    $ENV{$var} = $envmap{$var};
  }
}

# Search command results
sub found {
  my($list_cmd, $to_search) = @_;
  my $found = 0;
  for my $item (sys($list_cmd)) {
    if ($item =~ /$to_search/) {
      $found = 1;
    }
  }
  return $found;
}

# Clean up all the accounts except "eucalyptus"
sub clean_accounts {
  my @accounts = sys("euare-accountlist");
  for my $account (@accounts) {
    chomp($account);
    my @pair = split(qr/\s+/, $account);
    if ($pair[0] ne "eucalyptus") {
      sys("euare-accountdel -a $pair[0] -r");
    }
  }
  @accounts = sys("euare-accountlist");
  if (@accounts > 1 || !($accounts[0] =~ /^eucalyptus/)) {
    fail("failed to clean up accounts");
  }
}

#### LDAP sync tests ####

test_name( "Clean up first");
sys("rm -fr eucarc-*");

my $eucalyptus_admin_cred = get_cred("eucalyptus", "admin");
use_cred($eucalyptus_admin_cred);

clean_accounts();

sys( $EUCALYPTUS . "/usr/sbin/euca-modify-property -f $LICPROPERTY=$DEFAULTLIC");
sys("killall -9 slapd.32");
sys("rm -fr $SLAPDDATA/*");

if (!-e $SLAPDDATA) {
  sys("mkdir -p $SLAPDDATA");
}

# start LDAP service
test_name( "Start LDAP service");
sys("$LDAPROOT/$SLAPD -f $LDAPROOT/$SLAPDCONF -h \"ldap:/// ldapi:///\"");

test_name( "Wait for LDAP service to start");
sleep(5);

# populate with initial data
test_name( "Populate LDAP with initial data");
sys("ldapadd -x -H ldap://localhost -D \"cn=EucalyptusManager,dc=eucalyptus,dc=com\" -w zoomzoom -f $INITLDIF");

sleep(1);

# make sure the data is ready
test_name( "Ensure data is ready");
if (!found("ldapsearch -x -H ldap://localhost -b dc=eucalyptus,dc=com objectClass=*", qr/result: 0 Success/)) {
  fail("failed to populate LDAP data");
}
if (!found("ldapsearch -x -H ldap://localhost -b dc=eucalyptus,dc=com objectClass=*", qr/numEntries: 12/)) {
  fail("failed to populate LDAP data");
}

# start ldap sync
test_name( "Check that there is no license");
if (!found("$EUCALYPTUS/usr/sbin/euca-describe-properties", qr/'enable':'false'/)) {
  fail("invalid initial lic");
}

test_name( "Modify license property");
sys("$EUCALYPTUS/usr/sbin/euca-modify-property -f $LICPROPERTY=$TESTLIC");

test_name( "Check that the modification succeeded");
if (!found("$EUCALYPTUS/usr/sbin/euca-describe-properties", qr/"enable":"true"/)) {
  fail("failed to upload lic");
}

test_name( "Get the status of the sync");
if (!found("euare-getldapsyncstatus", qr/SyncEnabled\s+true/)) {
  fail("wrong sync enabled status");
}

# wait till sync finishes

test_name( "Poll sync status for completion");
my $start = time;
while ((time - $start) < $MAXSYNCTIME) {
  sleep 10;
  if (found("euare-getldapsyncstatus", qr/InSync\s+false/)) {
    last;
  }
}

if (!found("euare-getldapsyncstatus", qr/InSync\s+false/)) {
  fail("takes too long to sync");
}

# check if sync is right

test_name( "Validate that LDAP info was imported properly");
if (!found("euare-accountlist", qr/salesmarketing/)) {
  fail("missing account salesmarketing");
}
if (!found("euare-accountlist", qr/devsupport/)) {
  fail("missing account devsupport");
}

my $salesmarketing_cred = get_cred("salesmarketing", "admin");
use_cred($salesmarketing_cred);	
if (!found("euare-grouplistbypath", qr/arn:aws:iam::salesmarketing:group\/sales/)) {
  fail("missing group sales");
}
if (!found("euare-grouplistbypath", qr/arn:aws:iam::salesmarketing:group\/marketing/)) {
  fail("missing group marketing");
}
if (!found("euare-userlistbypath", qr/arn:aws:iam::salesmarketing:user\/johndoe/)) {
  fail("missing user johndoe");
}
if (!found("euare-userlistbypath", qr/arn:aws:iam::salesmarketing:user\/jackbauer/)) {
  fail("missing user jackbauer");
}
if (!found("euare-grouplistusers -g sales", qr/arn:aws:iam::salesmarketing:user\/johndoe/)) {
  fail("johndoe should be in sales");
}
if (!found("euare-grouplistusers -g marketing", qr/arn:aws:iam::salesmarketing:user\/jackbauer/)) {
  fail("jackbauer should be in marketing");
}

my $devsupport_cred = get_cred("devsupport", "admin");
use_cred($devsupport_cred);
if (!found("euare-grouplistbypath", qr/arn:aws:iam::devsupport:group\/engineering/)) {
  fail("missing group engineering");
}
if (!found("euare-grouplistbypath", qr/arn:aws:iam::devsupport:group\/support/)) {
  fail("missing group support");
}
if (!found("euare-userlistbypath", qr/arn:aws:iam::devsupport:user\/tomhanks/)) {
  fail("missing user tomhanks");
}
if (!found("euare-userlistbypath", qr/arn:aws:iam::devsupport:user\/marktwain/)) {
  fail("missing user marktwain");
}
if (!found("euare-userlistbypath", qr/arn:aws:iam::devsupport:user\/stevejobs/)) {
  fail("missing user stevejobs");
}
if (!found("euare-grouplistusers -g engineering", qr/arn:aws:iam::devsupport:user\/tomhanks/)) {
  fail("tomhanks should be in engineering");
}
if (!found("euare-grouplistusers -g support", qr/arn:aws:iam::devsupport:user\/marktwain/)) {
  fail("marktwainshould be in support");
}
if (!found("euare-grouplistusers -g support", qr/arn:aws:iam::devsupport:user\/stevejobs/)) {
  fail("stevejobs be in support");
}

# clean up at last
use_cred($eucalyptus_admin_cred);
clean_accounts();

sys("$EUCALYPTUS/usr/sbin/euca-modify-property -f $LICPROPERTY=$DEFAULTLIC");

sys("killall -9 slapd." . $ARCH);
sys("rm -fr $SLAPDDATA/*");
sys("rm -fr eucarc-*");
